voce.jar file requires the following libraries:

1. FreeTTS
	- cmu_us_kal.jar
	- cmulex.jar
	- en_us.jar
	- freetts.jar
	- jsapi.jar
2. Sphinx4
	- sphinx4.jar
	- WSJ_8gau_13dCep_16k_40mel_130Hz_6800Hz.jar